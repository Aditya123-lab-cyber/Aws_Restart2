userReply = input("Apakah kamu udah solat? (Enter yes or no) ")

if userReply == "yes":
    print("alhamdulliah")
elif userReply == "no":
    print("astagfirullah syaitonn")
    print("Ayo Solat sebelum terlambat, kematian tidak ada yang tau, terimakasih.")
else:
    print("Kata login kamu salah dan jangan sampe logout:)")

userReply = input("Would you like to buy stamps, buy an envelope, or make a copy? (Enter stamps, envelope, or copy) ")
if userReply == "stamps":
    print("We have many stamp designs to choose from.")
elif userReply == "envelope":
    print("We have many envelope sizes to choose from.")
elif userReply == "copy":
    copies = input("How many copies would you like? (Enter a number) ")
    print("Here are {} copies.".format(copies))
else:
    print("Thank you, please come again.")